create definer = test2@`%` trigger `insert_ phone`
    before insert
    on employee
    for each row
BEGIN
    -- 检查phone_number是否只包含数字
    IF NOT NEW.phone_number REGEXP '^[0-9]{11}$' THEN
        -- 如果是数字则插入
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Phone number must be exactly 11 digits.';
    END IF;
END;

