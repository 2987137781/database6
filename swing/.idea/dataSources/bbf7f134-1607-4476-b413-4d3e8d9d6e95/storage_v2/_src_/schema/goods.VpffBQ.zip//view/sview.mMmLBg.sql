create definer = test1@`%` view sview as
select `goods`.`stock`.`id` AS `id`, `goods`.`stock`.`name` AS `name`, `goods`.`stock`.`num` AS `num`
from `goods`.`stock`;

-- comment on column sview.id not supported: 商品号

-- comment on column sview.name not supported: 商品名

-- comment on column sview.num not supported: 商品库存

