create definer = test1@`%` trigger insert_authority
    before insert
    on employee
    for each row
BEGIN
    IF NEW.authority NOT IN (0, 1, 2) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid authority value';
    END IF;
END;

